﻿
namespace VisitorPattern
{
    public interface IBuildOld
    {
        void BuildNewHouse(string message);
        void Paint();
        void SetupInterior();
    }
    public class BuildNew3BHKHouse : IBuildOld
    {
        public void BuildNewHouse(string message)
        {
            Console.WriteLine("Building a 3bhk house");
        }

        public void Paint()
        {
            Console.WriteLine("Painting a 3bhk house");
        }

        public void SetupInterior()
        {
            Console.WriteLine("doing interior of a 3bhk house");
        }
    }

    public class BuildNew2BHKHouse : IBuildOld
    {
        public void BuildNewHouse(string message)
        {
            Console.WriteLine("Building a 2bhk house");
        }

        public void Paint()
        {
            Console.WriteLine("Painting a 2bhk house");
        }

        public void SetupInterior()
        {
            Console.WriteLine("doing interior of a 2bhk house");
        }
    }

}
