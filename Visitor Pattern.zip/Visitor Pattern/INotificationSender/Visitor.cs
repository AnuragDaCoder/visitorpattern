﻿namespace VisitorPattern
{
    public interface IVisitor
    {
        void Visit(IBuildNew buildOld);
    }

    internal class Paint2BHKVisitor : IVisitor
    {
        public void Visit(IBuildNew buildOld)
        {
            Console.WriteLine("Painting the house");
        }
    }

    internal class SetUp2BHKInteriorVisitor : IVisitor
    {
        public void Visit(IBuildNew buildOld)
        {
            Console.WriteLine("Interior Set up is done");
        }
    }

    internal class BuildExtraRoomIn2BHKVisitor : IVisitor
    {
        public void Visit(IBuildNew buildOld)
        {
            Console.WriteLine("Build extra room in 2bhk");
        }
    }

    internal class BuildAGarrageIn2BHKVisitor : IVisitor
    {
        public void Visit(IBuildNew buildOld)
        {
            Console.WriteLine("Build extra Garrage in 2bhk");
        }
    }
}
