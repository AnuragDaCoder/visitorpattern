﻿namespace VisitorPattern
{
    public interface IBuildNew
    {
        void BuildNewHouse(string message);
        void Accept(IVisitor visitor);
    }

    public class BuildNew3BHKHouseNew : IBuildNew
    {
        public void Accept(IVisitor visitor)
        {
            visitor.Visit(this);
        }

        public void BuildNewHouse(string message)
        {
            Console.WriteLine("Building a 3bhk house");
        }
    }

    public class BuildNew2BHKHouseNew : IBuildNew
    {
        public void Accept(IVisitor visitor)
        {
            visitor.Visit(this);
        }
        public void BuildNewHouse(string message)
        {
            Console.WriteLine("Building a 2bhk house");
        }
    }
}
