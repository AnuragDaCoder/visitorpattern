﻿using VisitorPattern;

var buildNew3BHKHouse = new BuildNew3BHKHouse();
buildNew3BHKHouse.BuildNewHouse("3 bhk house");
buildNew3BHKHouse.Paint();
buildNew3BHKHouse.SetupInterior();

Console.WriteLine("----------------------------------");
var buildNew2BHKHouse = new BuildNew2BHKHouse();
buildNew2BHKHouse.BuildNewHouse("2 bhk house");
buildNew2BHKHouse.Paint();
buildNew2BHKHouse.SetupInterior();

//Now if I want to add a garrage to 2bhk house
//I need to modify the interface...
//How visitor patterns solves ?
//IBuildNew - 1) keep the common thing in this interface - BuildNewHouse()
//            2) Accept() - this will accept many visitors
//               see the below code
//IVisitor - will have Visit Method


Console.WriteLine("----------------------------------");
//without modifying the interface...I am able to add all the visitors now..
var buildNew2BHKHouseNew = new BuildNew2BHKHouseNew();
buildNew2BHKHouseNew.BuildNewHouse("build 2bhk new house!!");
buildNew2BHKHouseNew.Accept(new Paint2BHKVisitor());
buildNew2BHKHouseNew.Accept(new BuildExtraRoomIn2BHKVisitor());
buildNew2BHKHouseNew.Accept(new SetUp2BHKInteriorVisitor());
buildNew2BHKHouseNew.Accept(new BuildAGarrageIn2BHKVisitor());




